		package ent;
		
		
		import java.util.ArrayList;
		import java.util.List;
		import java.util.Locale;
		import java.util.Scanner;
		
		import ent.funcionario;
		
		public class programa{
		public static void main(String[] args) {

		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);

		List<funcionario> list = new ArrayList<>();

		System.out.print("Quantos funcion�rios voc� quer registrar? ");
		int N = sc.nextInt();

		for (int i=0; i<N; i++) {

			System.out.println();
			System.out.println("Funcion�rio *" + (i + 1) + "*");
			System.out.print("Id: ");
			Integer id = sc.nextInt();
			while (hasId(list, id)) {
				System.out.println("Esse ID j� existe! Tente novamente com outro Id! ");
				id = sc.nextInt();
			}

			System.out.print("Nome: ");
			sc.nextLine();
			String name = sc.nextLine();
			System.out.print("Sal�rio: ");
			Double salary = sc.nextDouble();

			funcionario emp = new funcionario(id, name, salary);

			list.add(emp);
		}

			System.out.println();
			System.out.print("Insira o id do funcion�rio que ir� ter um aumento salarial : ");
			int idsalary = sc.nextInt();

		 

			funcionario func = list.stream().filter(x -> x.getId() == idsalary).findFirst().orElse(null);

	 {
		 	if (func == null) {
			System.out.println("Esse id n�o existe!");
		}
		 	else {
			System.out.print("Insira a porcentagem que deseja incrementar: ");
			double percent = sc.nextDouble();
			//list.get(pos).increaseSalary(percent);
			func.increaseSalary(percent);
		}
	
			System.out.println();
			System.out.println("Lista de funcion�rios:");
			for (funcionario e : list) {
			System.out.println(e);
		}		
	 }
			sc.close();
	}

			public static Integer position(List<funcionario> list, int id) {
			for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getId() == id) {
			return i;
			}
		}
			return null;
	}

			public static boolean hasId(List<funcionario> list, int id) {
			funcionario emp = list.stream().filter(x -> x.getId() == id).findFirst().orElse(null);
			return emp != null;
	}
}